USER MANUAL FOR STARTING HSG PlanPro+
1. Unzip the file
2. Check that Python (3.8 or later) is installed
3. Install the required dependencies by.
	3.1 in your command prompt, change your directory to the "HSG PlanPro+" app folder.
	3.2 run this command: pip install -r requirements.txt
4. In your command prompt, you can run the app with this command: streamlit run "HSG PlanPro+.py"